require("journeyman32.plugins-setup")
require("journeyman32.core.options")
require("journeyman32.core.keymaps")
require("journeyman32.plugins.comment")
require("journeyman32.plugins.nvim-tree")
require("journeyman32.plugins.lualine")
require("journeyman32.plugins.telescope")
require("journeyman32.plugins.nvim-cmp")


